package controle;

import java.sql.SQLException;
import java.util.logging.Logger;
import java.awt.event.ActionListener;
import javax.swing.table.TableModel;
import modelo.Contato;
import java.sql.SQLException;
import java.util.logging.*;
import model.bean.*;
import model.dao.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
               try{
                   new AgendaControle();
                   //new ViewJTable().setVisible(true);
               }catch (SQLException ex){
                   Logger.getLogger(AgendaControle.class.getName()).log(Level.SEVERE,null,ex);
               }
            }
        });
    }
}
