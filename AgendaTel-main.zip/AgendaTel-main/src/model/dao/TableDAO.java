package model.dao;
import connection.ConnectionFactory;
import java.sql.*;       
import java.util.*;
import javax.swing.JOptionPane;
import model.bean.Table;
        
public class TableDAO {
    public void create(Table p) throws SQLException{
    Connection con=ConnectionFactory.getConnection();
    PreparedStatement stmt = null;
    try{
       stmt = con.prepareStatement("INSERT INTO pessoa(Nome, Telefone) VALUES(?,?)");
       stmt.setString(1,p.getNome()); 
       stmt.setString(2,p.getTelefone());
       stmt.executeUpdate();
       JOptionPane.showMessageDialog(null,"Salvo com sucesso");
    }catch (SQLException ex)
    {JOptionPane.showMessageDialog(null,"Erro ao salvar"+ex);}
    finally{ ConnectionFactory.closeConnection(con,stmt);}
    }
    public List<Table>read()throws SQLException{
        //System.out.println("Oi!");
        Connection con = ConnectionFactory.getConnection();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Table>produtos = new ArrayList();
        try{
            stmt = con.prepareStatement("SELECT * FROM pessoa");
            rs = stmt.executeQuery();
            while(rs.next()){
                Table produto = new Table();
                produto.setNome(rs.getNString("Nome"));
                produto.setTelefone(rs.getNString("Telefone"));
                produtos.add(produto);
                //System.out.println(rs.getNString("Nome"));
               // System.out.println(rs.getNString("Telefone"));
                
            }
            
        }catch(SQLException ex)
        {JOptionPane.showMessageDialog(null,"Erro na leitura"+ex);}
        finally {ConnectionFactory.closeConnection(con,stmt,rs);}
        return produtos;
    }
    
   public void delete(Table p) throws SQLException{
       Connection con = ConnectionFactory.getConnection();
       PreparedStatement stmt = null;
       try{
           stmt = con.prepareStatement("DELETE FROM pessoa WHERE nome = ?");
           stmt.setString(1, p.getNome());
           stmt.executeUpdate();
           JOptionPane.showMessageDialog(null,"Excluído com sucesso");
           
       }catch (SQLException ex)
       {JOptionPane.showMessageDialog(null,"Erro ao excluir"+ex);}
       finally{ConnectionFactory.closeConnection(con,stmt);}
   }
}
